#!/bin/sh

(cd count ; make clean)
(cd features ; make clean)
(cd pseudo ; make clean)
(cd simple ; make clean)




