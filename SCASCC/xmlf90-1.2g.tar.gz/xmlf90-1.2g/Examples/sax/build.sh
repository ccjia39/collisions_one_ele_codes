#!/bin/sh

(cd count ; make)
(cd features ; make)
(cd pseudo ; make)
(cd simple ; make)



